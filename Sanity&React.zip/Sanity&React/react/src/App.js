import Movie from './components/Movies';
import './App.css'

function App() {
  return (
    <div>
      <Movie />
    </div>
  );
}

export default App;
