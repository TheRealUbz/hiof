import React, { useEffect } from "react";
import { useState } from 'react';
import { getMovies } from "../utils/movieService";

const Movie = (name, actor) => {
    const [data, setData] = useState([]);

    useEffect(() => {
       const fetchDataAsync = async() => {
            const allMovies = await getMovies();
            setData(allMovies);
       }
       fetchDataAsync();
    }, []);

    return(
        <>
        <h2>Movies</h2>
        <div class ="container">
            {data?.length > 0
            ? data.map((data) => <div class="movieDiv"><p class="movieName">Movie: {data.name}</p>  <p class="actorName">Actor: {data.actor}</p>
            <img src={data.imageUrl} class="movieImg" alt="Movie"></img>
            </div>)
        :null}
        </div>
        </>
    );
};
export default Movie;